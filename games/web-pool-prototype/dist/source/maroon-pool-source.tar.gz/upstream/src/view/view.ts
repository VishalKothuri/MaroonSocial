import { Scene, WebGLRenderer, Frustum, Matrix4, AmbientLight } from "three"
import { Camera } from "./camera"
import { Drawing } from "./drawing"
import { LineData } from "../events/chatevent"
import { AimEvent } from "../events/aimevent"
import { Table } from "../model/table"
import { Grid } from "./grid"
import { renderer } from "../utils/webgl"
import { Assets } from "./assets"
import { Snooker } from "../controller/rules/snooker"
import { Minimap } from "./minimap"
import { RevealTexture } from "./revealtexture"
import { Portraits, PortraitMode } from "./portraits"

export class View {
  readonly scene = new Scene()
  private readonly renderer: WebGLRenderer | undefined
  camera: Camera
  windowWidth = 1
  windowHeight = 1
  private cachedWidth = 1
  private cachedHeight = 1
  private lastFov = 0
  readonly element
  table: Table
  loadAssets = true
  assets: Assets
  drawing: Drawing
  minimap: Minimap
  portraits: Portraits
  /** ?image= source, loading in the background; not displayed yet. */
  readonly reveal: RevealTexture | null

  private readonly portraitMode: PortraitMode

  // Reuse objects to reduce garbage collection pressure in high-frequency rendering
  private readonly frustum = new Frustum()
  private readonly projScreenMatrix = new Matrix4()

  constructor(
    element,
    table,
    assets,
    portraitMode: PortraitMode = { roomVisible: false, singlePlayer: true }
  ) {
    this.element = element
    this.table = table
    this.assets = assets
    this.portraitMode = portraitMode
    this.renderer = renderer(element)

    if (element) {
      this.cachedWidth = element.offsetWidth
      this.cachedHeight = element.offsetHeight
      this.windowWidth = element.offsetWidth
      this.windowHeight = element.offsetHeight

      if (typeof ResizeObserver !== "undefined") {
        const observer = new ResizeObserver(() => {
          this.cachedWidth = element.offsetWidth
          this.cachedHeight = element.offsetHeight
        })
        observer.observe(element)
      }
    }

    this.camera = new Camera(
      element ? element.offsetWidth / element.offsetHeight : 1
    )
    this.drawing = new Drawing(
      this.scene,
      this.element as HTMLCanvasElement,
      () => this.camera.camera
    )
    this.minimap = new Minimap(this.scene, this.renderer)
    this.reveal = RevealTexture.fromLocation(this.renderer)
    this.initialiseScene()
    this.camera.tableMesh = this.table.mesh
  }

  addLine(data: LineData) {
    this.drawing.addLine(data)
  }

  clearLines() {
    this.drawing.clear()
  }

  undoLine() {
    this.drawing.undo()
  }

  set onLineDrawn(callback: (line: LineData) => void) {
    this.drawing.onLineDrawn = callback
  }

  update(elapsed, aim: AimEvent) {
    this.camera.update(elapsed, aim)
  }

  sizeChanged() {
    // Avoid reading offsetWidth/offsetHeight in high-frequency loops when ResizeObserver is supported.
    // This prevents layout thrashing.
    if (typeof ResizeObserver === "undefined") {
      return (
        this.windowWidth != this.element?.offsetWidth ||
        this.windowHeight != this.element?.offsetHeight
      )
    }
    return (
      this.windowWidth !== this.cachedWidth ||
      this.windowHeight !== this.cachedHeight
    )
  }

  updateSize() {
    const hasChanged = this.sizeChanged()
    if (hasChanged) {
      if (typeof ResizeObserver === "undefined") {
        this.windowWidth = this.element?.offsetWidth
        this.windowHeight = this.element?.offsetHeight
      } else {
        this.windowWidth = this.cachedWidth
        this.windowHeight = this.cachedHeight
      }
    }
    return hasChanged
  }

  render() {
    const isGracePeriod =
      this.camera.aimGraceStartT !== undefined &&
      this.camera.t - this.camera.aimGraceStartT < 5
    if (
      !isGracePeriod &&
      this.isInMotionNotVisible() &&
      (this.camera.mode === this.camera.aimView ||
        this.camera.mode === this.camera.aimzView)
    ) {
      this.camera.suggestMode(this.camera.topView)
    }
    this.renderCamera(this.camera)
  }

  renderCamera(cam) {
    const sizeChanged = this.updateSize()
    if (sizeChanged) {
      const width = this.windowWidth
      const height = this.windowHeight

      this.renderer?.setSize(width, height)
      this.renderer?.setViewport(0, 0, width, height)
      this.renderer?.setScissor(0, 0, width, height)
      this.renderer?.setScissorTest(true)

      cam.camera.aspect = width / height
    }

    if (sizeChanged || cam.camera.fov !== this.lastFov) {
      cam.camera.updateProjectionMatrix()
      this.lastFov = cam.camera.fov
    }

    this.renderer?.render(this.scene, cam.camera)
  }

  private initialiseScene() {
    this.scene.add(new AmbientLight(0x009922, 0.3))
    if (this.assets.background) {
      this.scene.add(this.assets.background)
    }
    this.scene.add(this.assets.table)
    this.table.mesh = this.assets.table
    const isSnooker = this.assets.rules.asset === Snooker.tablemodel
    this.scene.add(
      new Grid(this.assets.gridLineColor).generateLineSegments(isSnooker)
    )
    this.portraits = new Portraits(
      this.scene,
      this.portraitMode,
      this.assets.room?.xWall ?? 0
    )
    this.applyRevealTexture()
  }

  /**
   * ?image= takes over the cloth for the pool ruletypes (eightball, or the solo
   * reveal mode) on every table size. RevealTexture always supplies a full
   * hidden texture, so this is safe to call while the image is still in flight;
   * the reveal level is replayed once it arrives, and an unavailable image just
   * leaves the cloth grey. The reveal itself is driven by the score-update
   * funnel as the score goes up.
   *
   * The cushions and shadow are greyed to match that placeholder cloth, using
   * the same config the per-size cloth customisations feed.
   */
  private applyRevealTexture(): void {
    const reveal = this.reveal
    const ruletype = this.assets.ruletype
    if (!reveal || (ruletype !== "eightball" && ruletype !== "reveal")) return
    this.assets.applyClothColors(this.assets.table, {
      cushionColor: 0x6b6b6b,
      clothshadeColor: 0x0d0d0d,
    })
    // Same recipe the per-size cloth textures use, so the reveal picks up the
    // planar UV fix and the V repeat that fills the image.
    this.assets.applyCloth(this.assets.table, reveal.texture, {
      clothColor: 0xffffff,
      textureRepeatU: 1,
      textureRepeatV: 2,
    })
  }

  ballToCheck = 0

  isInMotionNotVisible() {
    const frustum = this.viewFrustum()
    const b = this.table.balls[this.ballToCheck++ % this.table.balls.length]
    return b.inMotion() && !frustum.intersectsObject(b.ballmesh.mesh)
  }

  viewFrustum() {
    const c = this.camera.camera
    this.frustum.setFromProjectionMatrix(
      this.projScreenMatrix.multiplyMatrices(
        c.projectionMatrix,
        c.matrixWorldInverse
      )
    )
    return this.frustum
  }
}
