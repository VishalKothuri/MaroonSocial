export const VERSION = 'maroon-preview-9cd48c5';
