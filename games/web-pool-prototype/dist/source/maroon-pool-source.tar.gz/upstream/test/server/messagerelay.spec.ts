import { expect } from "chai"
import { InMemoryMessageRelay } from "../mocks/inmemorymessagerelay"
import { MessageRelay } from "../../src/network/client/messagerelay"
import { BreakEvent } from "../../src/events/breakevent"
import { EventUtil } from "../../src/events/eventutil"
import { console as nodeConsole } from "node:console"

const jestConsole = globalThis.console

beforeEach(() => {
  globalThis.console = nodeConsole
})

afterEach(() => {
  globalThis.console = jestConsole
})

describe("MessageRelay", () => {
  const relay: MessageRelay = new InMemoryMessageRelay()

  it("validate subscriber receives published message", (done) => {
    const channel = "test"
    const message = EventUtil.serialise(new BreakEvent())
    relay.subscribe(channel, (msg) => {
      expect(msg).to.equal(message)
      done()
    })
    relay.publish(channel, message)
  })
})
